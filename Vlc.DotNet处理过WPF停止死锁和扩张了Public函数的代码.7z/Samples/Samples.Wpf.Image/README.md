﻿# WPF sample using Images

A sample WPF project demonstrating that we can use the Image class without using the WPF control (which is using Image anyway...)

Warning : Performances are even worse than other projects, because of the image effect and the fact that two videos are running.