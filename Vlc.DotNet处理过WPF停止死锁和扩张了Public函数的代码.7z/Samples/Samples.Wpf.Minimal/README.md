﻿# Minimal WPF sample

A sample project using .net framework 4.5 demonstrating how to get started with Vlc.DotNet in a WPF project.