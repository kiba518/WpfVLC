﻿# Advanced WinForms sample

A sample project using .net framework 4.5 demonstrating how to use advanced features of Vlc.DotNet in a WinForms project.