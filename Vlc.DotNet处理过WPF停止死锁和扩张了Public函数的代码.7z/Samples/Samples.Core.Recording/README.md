﻿# Recording sample

A .NET core application showing how to record a HLS stream from the internet