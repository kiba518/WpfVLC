﻿# Minimal WPF sample using the WinForms control

A sample project using .net framework 4.5 demonstrating how to get started with Vlc.DotNet in a WPF project using WinForms.

It might seem weird at first to use WinForms in a WPF project, but that's what have been used in Vlc.DotNet versions 2.x.
It should have better performances than the Wpf control, but this comes at the cost of having some issues in WPF integration. See :

- https://github.com/ZeBobo5/Vlc.DotNet/issues/249
- https://github.com/ZeBobo5/Vlc.DotNet/issues/296