﻿# Dialogs WPF sample

This project demonstrates how to use dialogs in a WPF app. This requires libVLC 3.0.0 or later.

For the sake of simplicity, I'm using [Mahapps.Metro](https://github.com/MahApps/MahApps.Metro) here, which is a very good library
to integrate a modern (UI) touch in your WPF application.

You could do the same thing in any app, like in pure WPF or in WinForms, but you'd probably have to implement your own dialogs.

The streams that this project is using don't exist. If you know of some sample URL, please make a PR.