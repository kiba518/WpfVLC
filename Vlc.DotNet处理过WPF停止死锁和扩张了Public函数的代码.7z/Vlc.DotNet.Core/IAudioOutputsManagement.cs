﻿namespace Vlc.DotNet.Core
{
    public interface IAudioOutputsManagement : IEnumerableManagement<AudioOutputDescription>
    {

    }
}
