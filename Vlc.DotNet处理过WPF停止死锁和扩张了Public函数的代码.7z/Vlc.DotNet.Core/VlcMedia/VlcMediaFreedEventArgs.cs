﻿using System;

namespace Vlc.DotNet.Core
{
    public class VlcMediaFreedEventArgs : EventArgs
    {
    }
}