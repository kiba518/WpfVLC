﻿using System;

namespace Vlc.DotNet.Core
{
    public sealed class VlcMediaPlayerStoppedEventArgs : EventArgs
    {
    }
}