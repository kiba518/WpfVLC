﻿using System;

namespace Vlc.DotNet.Core
{
    public sealed class VlcMediaPlayerPausedEventArgs : EventArgs
    {
    }
}