﻿namespace Vlc.DotNet.Core.Interops
{
    public class AudioOutputDevice
    {
        public string DeviceIdentifier;
        public string Description;
    }
}