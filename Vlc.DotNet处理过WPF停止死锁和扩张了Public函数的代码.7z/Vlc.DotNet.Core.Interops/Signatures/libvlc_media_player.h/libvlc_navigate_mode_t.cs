﻿namespace Vlc.DotNet.Core.Interops.Signatures
{
    public enum NavigateModes
    {
        Activate = 0,
        Up,
        Down,
        Left,
        Right
    }
}
