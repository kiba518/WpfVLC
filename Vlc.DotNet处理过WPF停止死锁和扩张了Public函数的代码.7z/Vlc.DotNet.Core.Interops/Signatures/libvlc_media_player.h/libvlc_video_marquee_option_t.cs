﻿namespace Vlc.DotNet.Core.Interops.Signatures
{
    public enum VideoMarqueeOptions
    {
        Enable = 0,
        Text,
        Color,
        Opacity,
        Position,
        Refresh,
        Size,
        Timeout,
        X,
        Y
    }
}
