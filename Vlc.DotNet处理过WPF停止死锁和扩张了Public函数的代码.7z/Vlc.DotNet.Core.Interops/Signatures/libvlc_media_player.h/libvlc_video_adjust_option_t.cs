﻿namespace Vlc.DotNet.Core.Interops.Signatures
{
    public enum VideoAdjustOptions
    {
        Enable = 0,
        Contrast,
        Brightness,
        Hue,
        Saturation,
        Gamma
    }
}
